Libraries needed to build the war file will go in here
Before it builds the war, ant will place them here when the build runs