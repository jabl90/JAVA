This directory contains source files for Web classes.  For example, 
Servlet definitions go here.