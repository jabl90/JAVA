package com.ricardo.services;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import com.ricardo.models.Pedido;

@Path("/pedidos")
public class PedidosService {
	
	private static final List<Pedido> pedidos = new ArrayList<Pedido>();
	
	static {
		pedidos.add(new Pedido(1,"Producto 1",23));
		pedidos.add(new Pedido(2,"Producto 2",24));
		pedidos.add(new Pedido(3,"Producto 3",25));
		pedidos.add(new Pedido(4,"Producto 4",26));
		pedidos.add(new Pedido(5,"Producto 5",27));
	}
	
	@GET
	@Produces("application/json")
	public List<Pedido> getPedidos(){
		return this.pedidos;
	}
	

}


