package com.netmind.pojos.books;

public interface EBook {
	public String read();
	public int genX();
}
