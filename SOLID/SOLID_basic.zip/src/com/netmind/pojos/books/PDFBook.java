package com.netmind.pojos.books;

public class PDFBook {
	public String read(){
		return "reading a pdf book.";
	}
}
