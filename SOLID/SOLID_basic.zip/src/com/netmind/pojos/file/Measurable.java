package com.netmind.pojos.file;

public interface Measurable {
	public int getLength();
	public int getSent();
}
