package com.netmind.pojos.file;

public class Video implements Measurable {

	@Override
	public int getLength() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getSent() {
		// TODO Auto-generated method stub
		return 0;
	}

}
