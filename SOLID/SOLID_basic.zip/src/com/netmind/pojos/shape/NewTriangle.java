package com.netmind.pojos.shape;

public class NewTriangle extends Shape{

	public int area() {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
