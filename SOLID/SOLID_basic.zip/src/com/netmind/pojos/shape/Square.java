package com.netmind.pojos.shape;

public class Square extends Rectangle {
	public void setHeight(int value) {
		this.width = value;
		this.height = value;
    }
 
    public void setWidth(int value) {
		this.width = value;
		this.height = value;
    }
}
